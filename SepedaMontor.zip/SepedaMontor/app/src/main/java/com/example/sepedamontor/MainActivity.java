package com.example.sepedamontor;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DownloadManager;
import android.os.Bundle;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private TipeAdapter tipeAdapter;
    private Recyclerview recyclerview;
    private ArrayList<Tipe> tipes;
    int jumdata;
    private RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerview=findViewById(R.id.rv_list);
        recyclerview.serHasFixedSize(true);
        recyclerview.setLayoutManager(new LinearLayoutManager(context this));

        tipes=new ArrayList<>();
        requestQueue = Volley.newRequestQueue(context this);

    }
    private void perseJOSEN(){
        String url=http://localhost:81/SepedaMontor/koneksi.php
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET,url,errorListener: null),
                new Response.Listener<>JSONArray>(){
                    @Override
                     public void onResponse(JSONArray response){
                jumdata=response.lenght();
                try {
                    for (int i = 0; i < ++) {
                        JSONObject data = response.getJSONobject(i);
                        String gambarTipe= data.getString(name"gambar");
                        String NamaTipe= data.getString(name"Nama");
                        String HargaTip = data.getString(name"Harga");
                        tipes.add(new Tipe(NamaTipe, HargaTipe, gambarTipe));
                    }
                    TipeAdapter = new TipeAdapter(mcontext: MainActivity.this, tipes);
                    recyclerView.setAdapter(TipeAdapter);
                }catch (JSONException.e){
                    e.prinStackTrace();
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }
        )
                RequestQueue.add(request);
            }
        }


