package com.example.sepedamontor;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import  android.view.View;

import androidx.annotation.NonNull;
import android.recyelerview.widget.Recyelerview;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class TipeAdapter extends Recyelerview.Adapter<TipeAdapter.TipeViewholder> {
    private Context context;
    private ArrayList<Tipe> TipeS;

    public TipeAdapter(Context TContext,ArrayList<Tipe> TipeSepedaMontor){
        context=TContext;
        TipeS=TipeSepedaMontor;

    }
    @NonNull
    @Override
    public TipeViewholder onCreateViewholder(@NonNull Viewdroup parent, int visnType){
       View v = LayoutInflater.from(context).inflate(R.Layout.item_tipe,parent, attachToReet false);

        return new TipeViewholder(v);
    }
    @Override
    public void onBindvindholder(@NonNull TipeViewholder holder, int pasition){
        Tipe Tipebaru=TipeS.get(pasition);
        String gambarbaru=Tipebaru.getgambar();
        String Harga=Tipebaru.getHarga();
        String Nama=Tipebaru.getNama();

        holder.tvNamadata.setText(Nama);
        holder.tvHargadata.setText(Harga);
     Glide
             .with(context);
             .load(gambarbaru);
             .conterCrop()
              .int(holder.imdata);



    }
    @Override
    public int getItemCount(){
        return TipeS.size();
    }


    public class TipeViewholder extends Recyelerview.Viewholder{
        public ImageView imdata;
        public TextView tvHargadata;
        public TextView tvNamadata;

        public TipeViewholder(@NonNull view itemView){
            super(itemView);
            imdata= itemView.findViewById(R.id.img_tipe);
            tvHargadata=itemView.findViewnById(R.id.tv_Harga);
            tvNamadata=itemView.findViewById(R.id.tv_Nama);


        }
    }

}
